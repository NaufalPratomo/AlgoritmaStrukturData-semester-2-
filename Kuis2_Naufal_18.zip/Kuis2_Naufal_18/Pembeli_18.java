package Kuis2_Naufal_18;

public class Pembeli_18 {
    public int nomorAntrian18;
    public String namaPembeli18;
    public String NoHp18;

    public Pembeli_18(int a, String b, String c) {
        this.nomorAntrian18 = a;
        this.namaPembeli18 = b;
        this.NoHp18 = c;
    }
}

