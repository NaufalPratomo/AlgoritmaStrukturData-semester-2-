package Kuis2_Naufal_18;

public class node_18 {
    Pembeli_18 pembeli18;
    node_18 next18;
    node_18 prev18;

    public node_18(Pembeli_18 a, node_18 b, node_18 c) {
        this.pembeli18 = a;
        this.next18 = b;
        this.prev18 = c;
    }
}
