package Kuis2_Naufal_18;

public class Pesanan_18 {
    public int kodePesanan18;
    public String namaPesanan18;
    public int harga18;

    public Pesanan_18(int a, String b, int d) {
        this.kodePesanan18 = a;
        this.namaPesanan18 = b;
        this.harga18 = d;
    }
}

